﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Windows.Forms;

namespace P0030482011044
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn1_Click(object sender, EventArgs e)
        {
            double[,] vetor = new double[4, 4];
            string auxiliar ;
            double somaTot=0, somaAuxiliar=0;
            double[] somaMes = new double[4];
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    auxiliar = Interaction.InputBox("Digite quanto deu na semana  " + (j + 1).ToString() + " no mês " +
                        (i + 1).ToString(), "entrada de dados");
                    if (double.TryParse(auxiliar, out vetor[i, j]))
                    {
                        vetor[i, j] = Convert.ToDouble(auxiliar);
                        somaTot = somaTot + vetor[i, j];
                        somaAuxiliar = somaAuxiliar + vetor[i, j];
                    }
                    else
                    {
                        j--;
                    }
                }
                somaMes[i] = somaAuxiliar;
                somaAuxiliar = 0;
            }
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    listBox1.Items.Add("total do mês: " + (i + 1).ToString() + " Semana: " +
                        (j + 1) + (" ") + (String.Format("{0:C2}", vetor[i, j])));
                }
                listBox1.Items.Add("-- Total Mês: " + (String.Format("{0:C2}", somaMes[i])));
                listBox1.Items.Add("------------------\n");
            }
            listBox1.Items.Add("Total Geral: " + (String.Format("{0:C2}", somaTot)));
        }
    }
}
      
